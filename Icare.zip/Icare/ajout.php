<?php
mysql_connect("localhost","root","admin") or die("Erreur");
mysql_select_db("Icare") or die ("base introuvable") ;
if ($_POST)
{
$nom=$_POST["nom"];
$dt=$_POST["d"];
$dure=$_POST["dure"];
$nbp=$_POST["nbf"];
$nbc=$_POST["nbc"];
$hp=$_POST["hp"];
if ()
{
    mysql_query('INSERT INTO medic values ("'.$nom.'","'.$dt.'","'.$dure.'","'.$nbp.'","'.$nbc.'","'.$hp'")') or die('Erreur: '.mysql_error());
    echo "bien ajouter";

}else echo ("insertion invalide")
}


?>